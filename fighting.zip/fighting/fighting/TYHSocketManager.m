//
//  TYHSocketManager.m
//  fighting
//
//  Created by 上海西信 on 17/3/1.
//  Copyright © 2017年 上海西信. All rights reserved.
//

#import "TYHSocketManager.h"
#import <sys/types.h>
#import <sys/socket.h>
#import <netinet/in.h>
#import <arpa/inet.h>

@interface TYHSocketManager()
@property (nonatomic,assign)int clientScoket;
@end

@implementation TYHSocketManager


+(instancetype)share{
    static dispatch_once_t onceToken;
    static TYHSocketManager *instance = nil;
 //   static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc]init];
        [instance initScoket];
//        [instance pullMSg];
        
    });
    return self;
}


- (void)initScoket{
//每次连接前，先断开连接
    if (_clientScoket != 0) {
        [self disConnect];
        _clientScoket = 0;
    }
    
    //创建客户端scoket


    
    
    
    
}


-(void)pullMsg{

    NSLog(@"hello world");
}





@end
