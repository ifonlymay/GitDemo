//
//  TYHSocketManager.h
//  fighting
//
//  Created by 上海西信 on 17/3/1.
//  Copyright © 2017年 上海西信. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TYHSocketManager : NSObject
+(instancetype)share;
-(void)connect;
-(void)disConnect;
-(void)sendMsg:(NSString *)msg;

@end
