//
//  ViewController.m
//  fighting
//
//  Created by 上海西信 on 17/2/28.
//  Copyright © 2017年 上海西信. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
- (void)sayHello;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //socket 创建并初始化，返回该socket的文件描述符，如果描述符为－1表示创建失败；
   // int socket(int addressFamily,int type,int protocol)
    
    NSLog(@"this is the branch test");
    
    
}




- (void)sayHello{
    NSLog(@"hello");
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
