//
//  main.m
//  fighting
//
//  Created by 上海西信 on 17/2/28.
//  Copyright © 2017年 上海西信. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
